public class ChainingExceptions extends Exception {

    public ChainingExceptions(String message, Throwable cause) {
        super(message, cause);
    }
}
